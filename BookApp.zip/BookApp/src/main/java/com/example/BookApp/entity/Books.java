package com.example.BookApp.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

@Table("Books")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Books {

    @Id
    private Long id;
    private String bookname;
    private String author;
}
