package com.example.BookApp.controller;

import com.example.BookApp.entity.Books;
import com.example.BookApp.repository.BooksRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController

public class BooksController {

     @Autowired
      BooksRepository booksRepository;

    @GetMapping(value = "/books")
    public Flux<Books> getAllBooks() {
        Flux<Books> booksFlux = booksRepository.findAll();
        return booksFlux;
    }

    @GetMapping(value = "/books/{id}")
    public Mono<Books> getBookById(@PathVariable Long id){
        Mono<Books> foundBook = booksRepository.findById(id);
        return foundBook;
    }

    @PostMapping(value = "/books")
    public Mono<Books> saveBook(@RequestBody Books book) {
        Mono<Books> savedBook = booksRepository.save(book);
        return savedBook;
    }

    @PutMapping(value = "/books/{id}")
    public Mono<Books> updateBook(@PathVariable Long id) {
        Mono<Books> foundBook = booksRepository.findById(id);

        return foundBook.flatMap(book -> {
            book.setAuthor("Stephen Hawkings");
            return booksRepository.save(book);
        });

    }

    @DeleteMapping(value = "/books/{id}")
    public void deleteBookById(@PathVariable Long id) {

        Mono<Books> foundBook = booksRepository.findById(id);

        foundBook.flatMap(book -> {
            return booksRepository.delete(book);
        });
    }
}
