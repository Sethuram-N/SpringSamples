package com.example.BookApp.repository;

import com.example.BookApp.entity.Books;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BooksRepository extends ReactiveCrudRepository<Books, Long> {
}
